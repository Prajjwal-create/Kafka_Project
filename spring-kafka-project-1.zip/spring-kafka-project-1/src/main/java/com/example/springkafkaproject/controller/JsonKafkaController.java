package com.example.springkafkaproject.controller;

import com.example.springkafkaproject.kafka.JsonKafkaProducerService;
import com.example.springkafkaproject.kafka.kafkaProducerService;
import com.example.springkafkaproject.modal.User;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("kafkarestjson")
public class JsonKafkaController {

    private JsonKafkaProducerService jsonKafkaProducerService;

    public JsonKafkaController(JsonKafkaProducerService jsonKafkaProducerService) {
        this.jsonKafkaProducerService = jsonKafkaProducerService;
    }
    //http:localhost:8080/kafkarestjson/publishJson
    @PostMapping("/publishJson")
    public ResponseEntity<String> publish(@RequestBody User user){
        jsonKafkaProducerService.sendMessage(user);
        return ResponseEntity.ok("Message send to kafka topic");
    }
}
