package com.example.springkafkaproject.controller;

import com.example.springkafkaproject.kafka.kafkaProducerService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("kafkarest")
public class MessageController {


    private kafkaProducerService kafkaProducerService;

    public MessageController(com.example.springkafkaproject.kafka.kafkaProducerService kafkaProducerService) {
        this.kafkaProducerService = kafkaProducerService;
    }
//http:localhost:8080/kafkarest/publish?message=hello kafka
    @GetMapping("/publish")
    public ResponseEntity<String> publish(@RequestParam("message") String message){
        kafkaProducerService.sendMessage(message);
        return ResponseEntity.ok("Message send to kafka topic");
    }
}
