package com.example.springkafkaproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringKafkaProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringKafkaProjectApplication.class, args);
	}

}
