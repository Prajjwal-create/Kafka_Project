package com.example.springkafkaproject.kafka;

import com.example.springkafkaproject.Test.Singleton;
import com.example.springkafkaproject.modal.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class JsonKafkaConsumerService {
    Singleton singleton= Singleton.getInstance();
    private static Logger logger = LoggerFactory.getLogger(kafkaConsumerService.class);

    @KafkaListener(topics = "javakafkatest", groupId = "myGroup")
    public void consume(User user) {
        logger.info(String.format("Message recieved -> %s", user));
    }
}
