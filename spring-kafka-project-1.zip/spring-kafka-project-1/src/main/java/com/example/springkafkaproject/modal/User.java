package com.example.springkafkaproject.modal;


public class User {

    int userId;

    String userName;

    String userProfession;

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setUserProfession(String userProfession) {
        this.userProfession = userProfession;
    }

    @Override
    public String toString() {
        return "User{" +
                "userId=" + userId +
                ", userName='" + userName + '\'' +
                ", userProfession='" + userProfession + '\'' +
                '}';
    }
}
